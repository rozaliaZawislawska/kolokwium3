﻿using KolokwiumPoprawkowe.Models;
using Microsoft.EntityFrameworkCore;

namespace KolokwiumPoprawkowe.Services;

public interface ITaskRepository
{
    public Task<Tasks?> GetTaskAsync(int IdTask);
    public Task AddReservationAsync(Tasks task);
    
};

public class TaskRepository: ITaskRepository
{
    public MyDbContext _MyDbContext;

    public TaskRepository(MyDbContext myDbContext)
    {
        _MyDbContext = myDbContext;
    }
    public async Task<Tasks> GetTaskAsync(int IdTask)
    {
        return await _MyDbContext.Task.SingleOrDefaultAsync(e => e.IdTask == IdTask);
    }

    public async Task AddReservationAsync(Tasks task)
    {
        await _MyDbContext.Task.AddAsync(task);
    }
}