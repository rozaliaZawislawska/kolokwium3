﻿namespace KolokwiumPoprawkowe.Models;

public class User
{
    public int IdUser { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public ICollection<Project> Project { get; set; }
    public ICollection<Tasks> Tasks { get; set; }
}