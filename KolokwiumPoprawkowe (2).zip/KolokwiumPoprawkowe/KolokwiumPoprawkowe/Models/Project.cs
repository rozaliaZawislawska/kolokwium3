﻿namespace KolokwiumPoprawkowe.Models;

public class Project
{
    public int IdProject { get; set; }
    public string Name { get; set; }
    public int IdDefaultAssignee { get; set; }
    public User User { get; set; }
    public ICollection<Tasks> Tasks { get; set; }
    public ICollection<User> Users { get; set; }
}