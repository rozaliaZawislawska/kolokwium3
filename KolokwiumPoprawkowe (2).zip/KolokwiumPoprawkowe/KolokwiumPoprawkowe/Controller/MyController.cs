﻿using KolokwiumPoprawkowe.Models;
using KolokwiumPoprawkowe.Services;
using Microsoft.AspNetCore.Mvc;

namespace KolokwiumPoprawkowe.Controller;


[Route("api/[controller]")]
[ApiController]
public class MyController: ControllerBase
{
    private readonly ITaksService _taskService;

    public MyController(ITaksService taskService)
    {
        _taskService = taskService;
    }
    
    [HttpGet("{projectId}")]
    public async Task<IActionResult> GetTasks(int projectId)
    {
        return Ok(await _taskService.GetTasks(projectId));
    }
    
    [HttpPost("tasks")]
    public async Task<IActionResult> CreateReservationAsync(CreateTaskDto request)
    {
        try
        {
            return StatusCode(201, await _taskService.CreateReservationAsync(request));
        }
        catch (ArgumentException exc)
        {
            return BadRequest(exc.Message);
        }
    }
}