﻿using KolokwiumPoprawkowe.Models;

namespace KolokwiumPoprawkowe.Services;

public interface ITaksService
{
    public Task<TaskDto> GetTasks(int projectId);
    public Task<int> CreateReservationAsync(CreateTaskDto taskDto);
    
}

public class TaskService: ITaksService
{
    public ITaskRepository TasksRepository { get; set; }
    public IUserRepository UserRepository { get; set; }

    public TaskService(ITaskRepository tasksRepository, IUserRepository userRepository)
    {
        TasksRepository = tasksRepository;
        UserRepository = userRepository;
    }
    public async Task<TaskDto> GetTasks(int projectId)
    {
        var task = await TasksRepository.GetTaskAsync(projectId);
        var reporter = await UserRepository.GetTaskAsync(task.IdReporter);
        var assignee = await UserRepository.GetTaskAsync(task.IdAssignee);
        
        var taskDto = new TaskDto
        {
            IdTask = task.IdTask,
            Name = task.Name,
            Description = task.Description,
            CreatedAt = task.CreatedAt,
            IdProject = task.IdProject,
            IdReporter = task.IdReporter,
            Reporter = new User
            {
                FirstName = reporter.FirstName,
                LastName = reporter.LastName
            },
            IdAssignee = task.IdAssignee,
            Assignee = new User
            {
                FirstName = assignee.FirstName,
                LastName = assignee.LastName
            }
        };
        return taskDto;
    }

    public async Task<int> CreateReservationAsync(CreateTaskDto taskDto)
    {
        var newTask = new Tasks
        {
            IdTask = 1,
            Name = taskDto.name,
            Description = taskDto.description,
            IdProject = taskDto.idProject,
            IdReporter = taskDto.idReporter,
            IdAssignee = taskDto.idAssignee,
            CreatedAt = DateTime.Today
                
        };
        await TasksRepository.AddReservationAsync(newTask);
        return 1;
    }
}