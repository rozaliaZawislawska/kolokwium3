﻿using KolokwiumPoprawkowe.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task = System.Threading.Tasks.Task;

namespace KolokwiumPoprawkowe.Configuration;

public class ProjectConfiguration: IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        builder.HasKey(e => e.IdProject);
        builder.Property(e => e.Name)
            .HasMaxLength(200)
            .IsRequired();
        builder.HasMany(e => e.Users)
            .WithMany(e => e.Project);
        builder.HasMany(e => e.Tasks)
            .WithOne(e => e.Project)
            .HasForeignKey(e => e.IdProject);
    }
}

public class TaskConfiguration: IEntityTypeConfiguration<Tasks>
{
    public void Configure(EntityTypeBuilder<Tasks> builder)
    {
        builder.HasKey(e => e.IdTask);
        builder.Property(e => e.Name)
            .HasMaxLength(200)
            .IsRequired();
        builder.Property(e => e.Description)
            .HasMaxLength(1000)
            .IsRequired();
    }
}

public class UserConfiguration: IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.HasKey(e => e.IdUser);
        builder.Property(e => e.FirstName)
            .HasMaxLength(200)
            .IsRequired();
        builder.Property(e => e.LastName)
            .HasMaxLength(200)
            .IsRequired();
        builder.HasMany(e => e.Tasks)
            .WithOne(e => e.User)
            .HasForeignKey(e => e.IdReporter);
        builder.HasMany(e => e.Tasks)
            .WithOne(e => e.User)
            .HasForeignKey(e => e.IdAssignee);
        builder.HasMany(e => e.Project)
            .WithOne(e => e.User)
            .HasForeignKey(e => e.IdDefaultAssignee);
    }
}