﻿using KolokwiumPoprawkowe.Models;
using Microsoft.EntityFrameworkCore;

namespace KolokwiumPoprawkowe.Services;

public interface IUserRepository
{
    public Task<UserDto> GetTaskAsync(int IdUser);
}

public class UserRepository
{
    public MyDbContext _MyDbContext;

    public UserRepository(MyDbContext myDbContext)
    {
        _MyDbContext = myDbContext;
    }
    public async Task<User?> GetTaskAsync(int IdUser)
    {
        return await _MyDbContext.User.SingleOrDefaultAsync(e => e.IdUser == IdUser);
    }
}