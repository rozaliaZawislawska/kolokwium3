﻿namespace KolokwiumPoprawkowe.Models;

public class CreateTaskDto
{
    public string name { get; set; }
    public int description { get; set; }
    public int idProject { get; set; }
    public int idReporter { get; set; }
    public int idAssignee { get; set; }
}