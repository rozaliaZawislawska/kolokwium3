﻿namespace KolokwiumPoprawkowe.Models;

public class Tasks
{
    public int IdTask { get; set; }
    public string Name { get; set; }
    public int Description { get; set; }
    public DateOnly CreatedAt { get; set; }
    public int IdProject { get; set; }
    public int IdReporter { get; set; }
    public int IdAssignee { get; set; }
    public Project Project { get; set; }
    public User User { get; set; }
}